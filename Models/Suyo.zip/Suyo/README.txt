Set material settings to:

Ambient: 0.7
Diffuse: 0.7
Specular: 0
Emissive: .3 (Grey)
Rough: 32
Brilliance: 1

On all (exept for eyes, where the emissive is set to 1)